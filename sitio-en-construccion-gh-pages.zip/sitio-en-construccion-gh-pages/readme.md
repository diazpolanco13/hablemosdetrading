# Plantilla estática responsive.

Perfecta para poner sitios web en estado de construcción o mantenimiento.

Ver la demo: https://mascueto.github.io/sitio-en-construccion/
